This Playwright project is a hobby project to practice Playwright
Currently in progress. 
